@echo off
chcp 65001 >nul
title Gestão de Clientes e Vendas - Moçambique
color 0A
echo ================================================================
echo    SISTEMA DE GESTÃO DE CLIENTES E VENDAS (MOÇAMBIQUE)
echo    A abrir aplicação em modo dedicado sem barras de navegador...
echo ================================================================
echo.
set "APP_URL=https://ais-dev-hc5bffivo4rqvrj5kk7i7a-656498759235.europe-west1.run.app"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%EDGE%" (
    start "" "%EDGE%" --app="%APP_URL%"
) else if exist "%CHROME%" (
    start "" "%CHROME%" --app="%APP_URL%"
) else (
    start "" "%APP_URL%"
)
timeout /t 2 >nul
exit
