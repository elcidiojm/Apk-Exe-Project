Set WshShell = CreateObject("WScript.Shell")
strDesktop = WshShell.SpecialFolders("Desktop")
strAppData = WshShell.ExpandEnvironmentStrings("%APPDATA%") & "\GestaoClientesVendas"
Set oLink = WshShell.CreateShortcut(strDesktop & "\Gestão de Clientes e Vendas.lnk")
edgePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe")
If Not CreateObject("Scripting.FileSystemObject").FileExists(edgePath) Then
    edgePath = WshShell.ExpandEnvironmentStrings("%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")
End If
oLink.TargetPath = edgePath
oLink.Arguments = "--app=https://ais-dev-hc5bffivo4rqvrj5kk7i7a-656498759235.europe-west1.run.app"
oLink.WindowStyle = 1
oLink.IconLocation = strAppData & "\app_icon.ico, 0"
oLink.Description = "Sistema de Gestão de Clientes e Vendas - Moçambique"
oLink.WorkingDirectory = strAppData
oLink.Save
