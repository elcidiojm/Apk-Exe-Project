@echo off
chcp 65001 >nul
title Instalador de Atalho - Gestão de Clientes e Vendas
color 0B
echo ================================================================
echo    A CRIAR ATALHO COM ÍCONE NO SEU AMBIENTE DE TRABALHO...
echo ================================================================
echo.
set "INSTALL_DIR=%APPDATA%\GestaoClientesVendas"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /Y "%~dp0app_icon.ico" "%INSTALL_DIR%\app_icon.ico" >nul 2>&1
cscript //nologo "%~dp0Criar_Atalho.vbs"
echo [OK] Atalho criado no Ambiente de Trabalho com o icone do sistema!
echo A iniciar aplicacao...
start "" "%USERPROFILE%\Desktop\Gestão de Clientes e Vendas.lnk"
timeout /t 3 >nul
exit
